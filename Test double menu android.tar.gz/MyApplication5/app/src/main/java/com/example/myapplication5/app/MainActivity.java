package com.example.myapplication5.app;

import android.app.Activity;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.support.v4.widget.DrawerLayout;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.example.myapplication5.app.t.ShoppingItemListFragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

//public class MainActivity extends FragmentActivity {
//
//    private static final String PAGER_TAG = "PagerActivity.PAGER_TAG";
//
//    @Override
//    protected void onCreate(Bundle savedInstance) {
//        super.onCreate(savedInstance);
//        setContentView(R.layout.tps_frag);
//        if (savedInstance == null) {
//            TestFragment frag = TestFragment.newInstance(0);
//            FragmentManager fm = getSupportFragmentManager();
//            fm.beginTransaction().add(R.id.layout_fragments, frag, PAGER_TAG).commit();
//        }
//    }
//}


public class MainActivity extends ActionBarActivity
        implements NavigationDrawerFragment.NavigationDrawerCallbacks {

    private NavigationDrawerFragment mNavigationDrawerFragment;
    TestFragment testFragment=null;
    private Integer lastMenu = null;
    private Integer lastTab = null;
    private Integer lastPositionNaviabled = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        if(savedInstanceState!=null){
            Toast.makeText(this, "Activity : onCreate : "+savedInstanceState.getInt("TAB"), Toast.LENGTH_SHORT).show();
            if(savedInstanceState.getInt("TAB",-1)!=-1) {
                lastTab = savedInstanceState.getInt("TAB");
            }
            if(savedInstanceState.getInt("MENU",-1)!=-1) {
                lastMenu = savedInstanceState.getInt("MENU");
            }
        }

        setContentView(R.layout.activity_main);

        mNavigationDrawerFragment = (NavigationDrawerFragment)
                getSupportFragmentManager().findFragmentById(R.id.navigation_drawer);

        mNavigationDrawerFragment.setUp(
                R.id.navigation_drawer,
                (DrawerLayout) findViewById(R.id.drawer_layout));

    }

    @Override
    public void onNavigationDrawerItemSelected(int position) {
        lastPositionNaviabled=position;
        Toast.makeText(this, "onNavigationDrawerItemSelected(" + position + ")/"+lastTab, Toast.LENGTH_SHORT).show();
        FragmentManager fragmentManager = getSupportFragmentManager();

        if(lastMenu!=null && lastMenu == position) {
            testFragment = TestFragment.newInstance(position, lastTab);
        }
        else{
            testFragment = TestFragment.newInstance(position,null);
        }

        fragmentManager.beginTransaction()
                .replace(R.id.container, testFragment)
                .commit();

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if(testFragment!=null) {
            outState.putInt("TAB", testFragment.getCurrentTab());

        }if(lastPositionNaviabled!=null) {
            outState.putInt("MENU", lastPositionNaviabled);
        }
    }

}
