package com.example.myapplication5.app.t.dto.post;

import com.example.myapplication5.app.t.dto.technical.PostDTO;

/**
 * Created by florian on 11/11/14.
 */
public class RegistrationDTO extends PostDTO {

    private String name;
    private String email;

    public RegistrationDTO() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "RegistrationDTO{" +
                "name='" + name + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
